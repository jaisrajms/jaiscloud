// Handlers for composition pattern 02 (TF4-2).
//
// The emulator's mock executor runs no code, so these handlers exist only so the
// deployment archive is a real Cloud Functions archive. The pattern asserts the
// control plane and the event delivery, not a function's runtime behaviour.
exports.handlePubsub = (event, context) => {
  console.log("pubsub event", event.id);
};

exports.handleStorage = (event, context) => {
  console.log("storage event", event.id);
};
